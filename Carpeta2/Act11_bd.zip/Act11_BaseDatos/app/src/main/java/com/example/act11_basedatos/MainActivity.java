package com.example.act11_basedatos;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DevDB myDb;

    //Inicializamos variables
    EditText etNombre, etDireccion, etTel, etCorreo, etID;
    Button btAgregar, btEliminar, btBuscar, btBuscarID, btBuscarNombre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Conectamos con componentes en XML
        etNombre = (EditText) findViewById(R.id.etNombre);
        etDireccion = (EditText) findViewById(R.id.etDireccion);
        etTel = (EditText) findViewById(R.id.etTel);
        etCorreo = (EditText) findViewById(R.id.etCorreo);
        etID = (EditText) findViewById(R.id.etID);
        btAgregar = (Button) findViewById(R.id.btAgregar);
        btEliminar = (Button) findViewById(R.id.btEliminar);
        btBuscar = (Button) findViewById(R.id.btBuscar);
        btBuscarID = (Button) findViewById(R.id.btBuscarID);
        btBuscarNombre = (Button) findViewById(R.id.btBuscarNombre);

        //Llama el constructor
        myDb = new DevDB(this);

        //Hablar al método cuando se da click al botón de add
        AddData();
        //Llamar método cuando se da click al botón de Buscar
        viewAll();
        //Llamar método cuando se da click al botón de Borrar
        Borrar();
        //BuscarID
        consultarID();
        //BuscarNombre
        consultarNombre();


    }

    //Metodo de añadir
    public void AddData(){
        btAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Convertimos
                //Agarramos texto
                boolean seInserta= myDb.insertarData(etNombre.getText().toString(), etDireccion.getText().toString(), etTel.getText().toString(), etCorreo.getText().toString());
                if(seInserta = true)
                    Toast.makeText(MainActivity.this, "Agregado correctamente",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this, "Problemas al insertar",Toast.LENGTH_LONG).show();
            }
        });
    }

    //Método para borrar
    public void Borrar() {
        btEliminar.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deletedRows = myDb.BorrarDatos(etID.getText().toString());
                        if(deletedRows > 0)
                            Toast.makeText(MainActivity.this,"Info Eliminada",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this,"Error",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    //Método para ver lo que hay
    public void viewAll(){
        btBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = myDb.mostrarData();
                //Checando si hay data o no
                if(res.getCount()== 0){
                    //Se mostrará el mensaje
                    Mensaje("Error","No se encontró info");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()){
                    buffer.append("Id: " + res.getString(0) + "\n");
                    buffer.append("Nombre: " + res.getString(1) + "\n");
                    buffer.append("Direccion: " + res.getString(2) + "\n");
                    buffer.append("Telefono: " + res.getString(3) + "\n");
                    buffer.append("Correo: " + res.getString(4) + "\n");
                }
                Mensaje("Información", buffer.toString() );
            }
        });
    }

    //Método que regresa un mensaje como alerta
    public void Mensaje(String title, String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        //Mostrar el mensaje
        builder.show();
    }

    //Consultar datos x id
    private void consultarID(){
        btBuscarID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = myDb.getWritableDatabase();
                String[] parametros = {etID.getText().toString()};
                String[] campos = {DevDB.COL_2, DevDB.COL_3, DevDB.COL_4, DevDB.COL_5};

                Cursor cursor = db.query(DevDB.TABLE_NAME, campos, DevDB.COL_1 + "=?", parametros, null, null, null);
                cursor.moveToFirst();
                etNombre.setText(cursor.getString(0));
                etDireccion.setText(cursor.getString(1));
                etTel.setText(cursor.getString(2));
                etCorreo.setText(cursor.getString(3));
            }
        });
    }

    //Consultar datos x nombre
    private void consultarNombre(){
        btBuscarNombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = myDb.getWritableDatabase();
                String[] parametros = {etNombre.getText().toString()};
                String[] campos = {DevDB.COL_1, DevDB.COL_3, DevDB.COL_4, DevDB.COL_5};

                Cursor cursor = db.query(DevDB.TABLE_NAME, campos, DevDB.COL_2 + "=?", parametros, null, null, null);
                cursor.moveToFirst();
                etID.setText(cursor.getString(0));
                etDireccion.setText(cursor.getString(1));
                etTel.setText(cursor.getString(2));
                etCorreo.setText(cursor.getString(3));
            }
        });
    }
}