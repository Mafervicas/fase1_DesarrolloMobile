package com.example.act11_basedatos;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class DevDB extends SQLiteOpenHelper {

    //Creamos base de datos
    //Minutos afectados/Minutos totales indisponibilidad
    //100- indisponibilidad
    public static final String DATABASE_NAME = "Act11.db";
    public static final String TABLE_NAME = "clientes_tb";
    //Columnas
    public static final String COL_1= "ID";
    public static final String COL_2 = "Nombre";
    public static final String COL_3 = "Direccion";
    public static final String COL_4 = "Tel";
    public static final String COL_5 = "Correo";

    //Constructor crea la tabla
    public DevDB(Context context) {
        super(context, DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Ejecutará el query
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, NOMBRE TEXT, DIRECCION TEXT, TEL TEXT, CORREO TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Borra la tabla
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        //La vuelve a crear
        onCreate(db);
    }

    //Método para incertar datos
    public boolean insertarData(String nombre, String direccion, String tel, String correo){
        //Instanciamos
        SQLiteDatabase db = this.getWritableDatabase();
        //Asignaremos los valores
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, nombre);
        contentValues.put(COL_3, direccion);
        contentValues.put(COL_4, tel);
        contentValues.put(COL_5, correo);
        //Insertamos data
        long result = db.insert(TABLE_NAME,null, contentValues);
        //Regresamos si se pusieron los valores o no
        if(result == -1)
            return false;
        else
            return true;
    }



    //Método para borrar datos
    public Integer BorrarDatos(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "ID = ?",new String[] {id});
    }

    //Método para Mostrar datos
    public Cursor mostrarData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLE_NAME, null);
        return res;

    }
}
