//
//  AguaViewController.swift
//  ProyectoFinal
//
//  Created by user183054 on 5/22/21.
//  Copyright © 2021 user183054. All rights reserved.
//

import UIKit

class AguaViewController: UIViewController {

    
    @IBAction func Calcula(_ sender: Any) {
        let w = Double(peso2Field.text!)
        let agua = w! * 35
        mlsLabel.text=String(format: "%.2f", agua)    }
    
    @IBOutlet var peso2Field: UITextField!
    @IBOutlet var mlsLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTextFields()    }
    
    private func configureTextFields(){
            peso2Field.delegate = self
            
        }
        

    }
        
        extension AguaViewController: UITextFieldDelegate{
            func textFieldShouldReturn(_ textField: UITextField) -> Bool {
                textField.resignFirstResponder()
                return true
            }
}
