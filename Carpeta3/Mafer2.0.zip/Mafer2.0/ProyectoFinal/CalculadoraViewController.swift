//
//  CalculadoraViewController.swift
//  ProyectoFinal
//
//  Created by user183054 on 5/19/21.
//  Copyright © 2021 user183054. All rights reserved.
//

import UIKit

class CalculadoraViewController: UIViewController {
    
    //Jalas todos los botones
    @IBOutlet var pesoField: UITextField!
    @IBOutlet var alturaField: UITextField!
    @IBOutlet var resultLabel: UILabel!
    @IBOutlet var estadoLabel: UILabel!
    @IBOutlet var edadField: UITextField!
    
    
    //Creas la accion del boton
    @IBAction func CalculaButton(_ sender: Any) {
        //Calcular IMC
        let h = Double(alturaField.text!)
        let w = Double(pesoField.text!)
        let imc = w! / pow(h!,2)
        resultLabel.text=String(format: "%.2f", imc)
        //Decir si es Saludable o no
        if imc < 18.5 {
            estadoLabel.text=String("Bajo peso")
        } else if imc < 24.9 {
            estadoLabel.text=String("Saludable")
        } else if imc < 34.9 {
            estadoLabel.text=String("Obesidad 1")
        } else if imc < 39.9{
            estadoLabel.text=String("Obesidad 2")
        } else {
            estadoLabel.text=String("Obesidad 3")
        }
        
    }
    
 
    
    //Configuras para que se pueda desaparecer el teclado
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTextFields()}
    private func configureTextFields(){
        pesoField.delegate = self
        alturaField.delegate = self
        edadField.delegate = self
        
    }
    

}
    
    extension CalculadoraViewController: UITextFieldDelegate{
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }
}
