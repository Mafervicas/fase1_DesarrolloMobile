//
//  LinksViewController.swift
//  ProyectoFinal
//
//  Created by user183054 on 5/22/21.
//  Copyright © 2021 user183054. All rights reserved.
//

import UIKit

class LinksViewController: UIViewController {
    
    
    @IBAction func link1(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://pin.it/7z0ed5G")! as URL, options: [:], completionHandler: nil)    }
    
    @IBAction func Link2(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.youtube.com/playlist?list=PLZxAgr_1BtHpTCgiWkY4-RIJmLpSqR_Po")! as URL, options: [:], completionHandler: nil)    }
    
    @IBAction func Link3(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.instagram.com/fitfemalesclub/?hl=es-la")! as URL, options: [:], completionHandler: nil)}
    
    
    @IBAction func link4(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.instagram.com/katb_fit/?hl=es-la")! as URL, options: [:], completionHandler: nil)}
    
    @IBAction func link5(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.instagram.com/kenyacoopercoach/?hl=es-la")! as URL, options: [:], completionHandler: nil)}
    
    @IBAction func link6(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.vitonica.com")! as URL, options: [:], completionHandler: nil)}
    
    
    @IBAction func link7(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://winniegana.com")! as URL, options: [:], completionHandler: nil)}
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    


}
