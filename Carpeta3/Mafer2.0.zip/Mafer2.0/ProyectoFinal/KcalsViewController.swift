//
//  KcalsViewController.swift
//  ProyectoFinal
//
//  Created by user183054 on 5/22/21.
//  Copyright © 2021 user183054. All rights reserved.
//

import UIKit

class KcalsViewController: UIViewController {
    
    @IBOutlet var kcalsTotalField: UITextField!
    @IBOutlet var KcalsIngField: UITextField!
    @IBOutlet var comidaslbl: UILabel!
    @IBOutlet var restanteslbl: UILabel!
    

    
    
    @IBAction func Calcula(_ sender: Any) {
        let kcalsTotales = Int(kcalsTotalField.text!)
        let KcalsIng = Int(KcalsIngField.text!)
        let restante = kcalsTotales! - KcalsIng!
        comidaslbl.text=String("\(KcalsIngField.text!)")
        restanteslbl.text=String("\(restante)")
    
        
        
        
    }
        
    
    override func viewDidLoad() {
            super.viewDidLoad()
            configureTextFields()    }
        
        private func configureTextFields(){
                kcalsTotalField.delegate = self
                KcalsIngField.delegate = self
                
            }

        }
            
            extension KcalsViewController: UITextFieldDelegate{
                func textFieldShouldReturn(_ textField: UITextField) -> Bool {
                    textField.resignFirstResponder()
                    return true
                }
    }

