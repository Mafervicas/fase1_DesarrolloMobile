//
//  CronometroViewController.swift
//  ProyectoFinal
//
//  Created by user183054 on 5/18/21.
//  Copyright © 2021 user183054. All rights reserved.
//

import UIKit

class CronometroViewController: UIViewController {
    
    //Label 0
    @IBOutlet weak var lblnum: UILabel!
    //Para ocultar
    @IBOutlet var startOutlet: UIButton!
    
    //Variables
    // Creas una variable de timer
     var timer = Timer ()
     var (hours, minutes, seconds, fractions) = (0,0,0,0)

    
    @IBOutlet var fractionsLabel: UILabel!
    
    
    //Botones
    @IBAction func Start(_ sender: UIButton) {
        timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(CronometroViewController.keepTimer), userInfo: nil, repeats: true)
        startOutlet.isHidden = true}
    
    //Si oprime Pausa
    @IBAction func Pause(_ sender: UIButton) {
        timer.invalidate()
        startOutlet.isHidden = false }
    
    //Si oprime reset
    @IBAction func Reset(_ sender: UIButton) {
        timer.invalidate()
        (hours, minutes, seconds, fractions) = (0,0,0,0)
        lblnum.text = "00:00:00"
        fractionsLabel.text = ".00"
       }
    
    //Funcion de tiempo
    @objc func keepTimer(){
        fractions += 1
        if fractions > 99 {
            seconds += 1
            fractions = 0}
        if seconds == 60 {
            minutes += 1
            seconds = 0}
        if minutes == 60 {
            hours += 1
            minutes = 0}
        //Para que los 0 a la izquierda se queden
        let secondsString = seconds > 9 ? "\(seconds)" : "0\(seconds)"
        let minutesString = minutes > 9 ? "\(minutes)" : "0\(minutes)"
        let hoursString = hours > 9 ? "\(hours)" : "0\(hours)"
        
        // Ahora si lo actualizas en el label
        lblnum.text = "\(hoursString):\(minutesString):\(secondsString)"
        fractionsLabel.text = ".\(fractions)"    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   
}
